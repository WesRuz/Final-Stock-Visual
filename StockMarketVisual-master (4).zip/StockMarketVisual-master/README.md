# Visualizing stock market data

## CPSC 583 project

### Interactive visuals to help understand how the stock market reacted in the last 5 years.
Check it out [here](https://gordwest.github.io/StockMarketVisual/).
